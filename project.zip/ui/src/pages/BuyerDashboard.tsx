// ui/src/pages/BuyerDashboard.tsx

import React, { useState } from "react";
import Marketplace from "../components/buyer/Marketplace";
import PortfolioManager from "../components/buyer/PortfolioManager";
import BorrowingTerminal from "../components/buyer/BorrowingTerminal";
import SyncInventory from "../components/network/SyncInventory";

type BuyerTab = "market" | "portfolio" | "loans" | "network";

export default function BuyerDashboard() {
  const [activeTab, setActiveTab] = useState<BuyerTab>("market");

  const tabStyle = (id: BuyerTab) => ({
    padding: '1rem 1.5rem',
    background: activeTab === id ? 'var(--success)' : 'transparent',
    color: activeTab === id ? 'white' : 'var(--text-muted)',
    border: 'none',
    borderBottom: activeTab === id ? '3px solid white' : 'none',
    cursor: 'pointer',
    fontWeight: 'bold' as const
  });

  return (
    <div className="container">
      <div className="flex-between" style={{ marginBottom: "2rem", borderBottom: '1px solid var(--border)' }}>
        <h1>Investor Terminal</h1>
        <div style={{ display: 'flex', gap: '5px' }}>
          <button style={tabStyle("market")} onClick={() => setActiveTab("market")}>Marketplace</button>
          <button style={tabStyle("portfolio")} onClick={() => setActiveTab("portfolio")}>Portfolio</button>
          <button style={tabStyle("loans")} onClick={() => setActiveTab("loans")}>Borrowing</button>
          <button style={tabStyle("network")} onClick={() => setActiveTab("network")}>Network</button>
        </div>
      </div>

      {activeTab === "market" && <Marketplace />}
      {activeTab === "portfolio" && <PortfolioManager />}
      {activeTab === "loans" && <BorrowingTerminal />}
      {activeTab === "network" && <SyncInventory />}
    </div>
  );
}