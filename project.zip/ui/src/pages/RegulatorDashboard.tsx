import React, { useState } from "react";
import { useStreamQueries } from "@daml/react";
import { LendingRegulatorView } from "@daml.js/CantonSuite-0.1.0/lib/Lending/Loans";

import SolvencyMonitor from "../components/regulator/SolvencyMonitor";
import HashedLedger from "../components/regulator/HashedLedger";
import RiskAlerts from "../components/regulator/RiskAlerts";

type RegulatorTab = "ledger" | "solvency" | "risk" | "lending";

export default function RegulatorDashboard() {
  const [activeTab, setActiveTab] = useState<RegulatorTab>("ledger");
  const { contracts: lendingAudit } = useStreamQueries(LendingRegulatorView);

  const tabStyle = (id: RegulatorTab) => ({
    padding: '1rem 1.5rem',
    background: activeTab === id ? 'var(--warning)' : 'transparent',
    color: activeTab === id ? 'black' : 'var(--text-muted)',
    border: 'none',
    borderBottom: activeTab === id ? '3px solid white' : 'none',
    cursor: 'pointer',
    fontWeight: 'bold' as const
  });

  return (
    <div className="container">
      <div className="flex-between" style={{ marginBottom: "2rem", borderBottom: '1px solid var(--border)' }}>
        <h1 style={{ color: 'var(--warning)' }}>Oversight & Audit Node</h1>
        <div style={{ display: 'flex', gap: '5px' }}>
          <button style={tabStyle("ledger")} onClick={() => setActiveTab("ledger")}>Hashed Ledger</button>
          <button style={tabStyle("solvency")} onClick={() => setActiveTab("solvency")}>Solvency</button>
          <button style={tabStyle("risk")} onClick={() => setActiveTab("risk")}>Risk/AML</button>
          <button style={tabStyle("lending")} onClick={() => setActiveTab("lending")}>DeFi Oversight</button>
        </div>
      </div>

      {activeTab === "ledger" && <HashedLedger />}
      {activeTab === "solvency" && <SolvencyMonitor />}
      {activeTab === "risk" && <RiskAlerts />}

      {activeTab === "lending" && (
        <div className="card">
          <h3>DeFi Stability & LTV Audit</h3>
          <table>
            <thead>
              <tr>
                <th>Loan ID</th>
                <th>Principal</th>
                <th>Collateral Ratio</th>
                <th>Status</th>
                <th>Event</th>
              </tr>
            </thead>
            <tbody>
              {lendingAudit.map(l => (
                <tr key={l.contractId}>
                  <td><code style={{fontSize:'0.7rem'}}>{l.payload.loanIdHash.substring(0,12)}...</code></td>
                  <td>${Number(l.payload.principal).toLocaleString()}</td>
                  <td style={{ color: Number(l.payload.collateralRatio) < 120 ? 'var(--danger)' : 'var(--success)' }}>
                    {l.payload.collateralRatio}%
                  </td>
                  <td><span className="badge badge-blue">{l.payload.status}</span></td>
                  <td>{l.payload.eventType}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* EXPORT LOG BUTTON */}
      <button 
        className="btn-outline" 
        style={{ marginTop: '2rem' }}
        onClick={() => alert("Generating Signed PDF Audit Report...")}
      >
        📥 Download Certified Audit Log
      </button>
    </div>
  );
}