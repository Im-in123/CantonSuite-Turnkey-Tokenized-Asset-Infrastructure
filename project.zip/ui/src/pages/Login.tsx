// ui/src/pages/Login.tsx

import React, { useState, useEffect } from "react";
import CantonIAM from "../services/CantonIAM";
import { LoadingSpinner } from "../components/LoadingSpinner";

export default function Login({ onLogin }: { onLogin: (t: string, p: string) => void }) {
  const [parties, setParties] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const iam = CantonIAM.getInstance();

  useEffect(() => {
    iam.discoverParties().then(setParties).finally(() => setLoading(false));
  }, []);

  const handleConnect = (name: string) => {
    const userPartyId = parties[name];
    
    // 1. Find the institutional identities needed for global discovery
    const publicMarketId = parties['PublicMarket'];
    const amuletId = parties['AmuletApp'];

    // 2. Build the visibility array (ReadAs)
    // Every user needs to read as themselves, the PublicMarket (for assets), 
    // and AmuletApp (for mining rounds/sync status).
    const publicVisibility = [publicMarketId, amuletId].filter(id => !!id);

    // 3. Generate the token that allows the user to see the "Global" data
    const token = iam.createUserToken(userPartyId, publicVisibility);
    
    iam.setSession(token, userPartyId);
    onLogin(token, userPartyId);
  };

  if (loading) return <LoadingSpinner text="Synchronizing Ledger Identities..." />;

  const categories = [
    { title: "GOVERNANCE", color: "#8b5cf6", members: ["ComplianceOfficer", "Regulator", "PlatformIssuer"] },
    { title: "INVESTORS", color: "#10b981", members: ["Alice", "Bob", "HedgeFund"] },
    { title: "DEFI NODES", color: "#f59e0b", members: ["PoolOperator", "Bank", "Borrower"] }
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#0b0e11', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ maxWidth: '900px', width: '100%', padding: '2rem' }}>
        <h1 style={{ textAlign: 'center', color: '#3b82f6', marginBottom: '3rem' }}>CANTON SUITE+</h1>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem' }}>
          {categories.map(cat => (
            <div key={cat.title} className="card" style={{ borderTop: `4px solid ${cat.color}` }}>
              <h4 style={{ color: cat.color, fontSize: '0.8rem', marginBottom: '1.5rem' }}>{cat.title}</h4>
              {cat.members.map(m => (
                <button key={m} className="btn-connect" onClick={() => handleConnect(m)} disabled={!parties[m]}>
                  {m.replace(/([A-Z])/g, ' $1').trim()}
                </button>
              ))}
            </div>
          ))}
        </div>
        <style>{`
          .btn-connect { 
            width: 100%; 
            padding: 12px; 
            margin-bottom: 10px; 
            cursor: pointer; 
            background: #1c2128; 
            color: white; 
            border: 1px solid #2f343e; 
            border-radius: 6px; 
            text-align: left; 
            transition: 0.2s; 
            font-family: monospace; 
            font-size: 0.85rem; 
          } 
          .btn-connect:hover:not(:disabled) { 
            border-color: #3b82f6; 
            background: #24292f; 
            transform: translateX(4px); 
          }
          .card {
            background: #161b22;
            padding: 1.5rem;
            border-radius: 12px;
            border: 1px solid #30363d;
          }
        `}</style>
      </div>
    </div>
  );
}