// ui/src/pages/IssuerDashboard.tsx

import React, { useState } from "react";
import { useParty, useStreamQueries } from "@daml/react";

// Domain Specialized Components
import AssetManager from "../components/issuer/AssetManager";
import TradePipeline from "../components/issuer/TradePipeline";
import LendingProcessor from "../components/issuer/LendingProcessor";
import CorporateActions from "../components/issuer/CorporateActions";

// Network specialized components
import SyncInventory from "../components/network/SyncInventory";
import MigrationManager from "../components/network/MigrationManager";

// Icons/UI logic
import { TableSkeleton } from "../components/LoadingSpinner";
import MarketPresence from "../components/issuer/MarketPresence";

 
type DashboardTab = "assets" | "trades" | "lending" | "market" | "actions" | "network";

export default function IssuerDashboard() {
  const party = useParty();
  const [activeTab, setActiveTab] = useState<DashboardTab>("assets");

  // Basic styling for the sub-navigation
  const tabStyle = (id: DashboardTab) => ({
    padding: '0.8rem 1.5rem',
    background: activeTab === id ? 'var(--primary)' : 'transparent',
    color: activeTab === id ? 'white' : 'var(--text-muted)',
    border: 'none',
    borderBottom: activeTab === id ? '3px solid white' : '2px solid transparent',
    cursor: 'pointer',
    fontWeight: 'bold' as const,
    fontSize: '0.85rem',
    transition: '0.2s all ease-in-out',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  });

  return (
    <div className="container" style={{ paddingBottom: '4rem' }}>
      {/* 1. INSTITUTIONAL NAVIGATION BAR */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        marginBottom: '2.5rem',
        borderBottom: '1px solid var(--border)',
        paddingBottom: '0.5rem'
      }}>
        <h1 style={{ margin: 0, fontSize: '1.5rem' }}>Issuer Command Center</h1>
        
        <div style={{ display: 'flex', background: 'rgba(255,255,255,0.03)', borderRadius: '8px', padding: '4px' }}>
          <button style={tabStyle("assets")} onClick={() => setActiveTab("assets")}>
            Inventory
          </button>
          <button style={tabStyle("market")} onClick={() => setActiveTab("market")}>
  Market Presence
</button>
          <button style={tabStyle("trades")} onClick={() => setActiveTab("trades")}>
            Settlement Pipe
          </button>
          <button style={tabStyle("lending")} onClick={() => setActiveTab("lending")}>
            DeFi Pools
          </button>
          <button style={tabStyle("actions")} onClick={() => setActiveTab("actions")}>
            Corp Actions
          </button>
          <button style={tabStyle("network")} onClick={() => setActiveTab("network")}>
            🌐 Network/Sync
          </button>
        </div>
      </div>

      {/* 2. TAB VIEW ROUTING */}
      <div className="fade-in">
        
        {/* ASSET LIFECYCLE TAB */}
        {activeTab === "assets" && (
          <AssetManager />
        )}
        {activeTab === "market" && (
          <MarketPresence />
        )}
        {/* TRADE & SETTLEMENT PIPELINE */}
        {activeTab === "trades" && (
          <TradePipeline />
        )}

        {/* DEFI LENDING & LIQUIDITY */}
        {activeTab === "lending" && (
          <LendingProcessor />
        )}

        {/* CORPORATE ACTIONS (Yields/Redemptions) */}
        {activeTab === "actions" && (
          <CorporateActions />
        )}

        {/* NETWORK INFRASTRUCTURE (Cross-Sync Moves) */}
        {activeTab === "network" && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div className="flex-column" style={{ gap: '2rem' }}>
              <SyncInventory />
              <div className="card" style={{ background: '#0d1117', border: '1px dashed #30363d' }}>
                <h4 style={{ color: '#58a6ff', margin: '0 0 1rem 0' }}>Security Protocol</h4>
                <p className="text-muted" style={{ fontSize: '0.8rem', lineHeight: '1.4' }}>
                  Cross-synchronizer moves involve a locking phase and a completion phase. 
                  Assets in transit are temporarily marked as <code>Locked</code> to prevent 
                  double-spending during network migration.
                </p>
              </div>
            </div>
            <MigrationManager />
          </div>
        )}

      </div>

      {/* 3. GLOBAL STATUS FOOTER (Optional context) */}
      <div style={{ 
        position: 'fixed', bottom: '20px', left: '20px', 
        fontSize: '0.7rem', color: 'var(--text-muted)',
        background: 'var(--bg-dark)', padding: '5px 12px', borderRadius: '4px', border: '1px solid var(--border)'
      }}>
        Issuer Node: <span style={{ fontFamily: 'monospace', color: 'var(--primary)' }}>{party.substring(0, 20)}...</span>
      </div>

      <style>{`
        .fade-in { animation: fadeIn 0.3s ease-in; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
        .flex-column { display: flex; flexDirection: column; }
      `}</style>
    </div>
  );
}