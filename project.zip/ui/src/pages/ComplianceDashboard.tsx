// ui/src/pages/ComplianceDashboard.tsx

import React, { useState } from "react";
import { useLedger, useParty, useStreamQueries } from "@daml/react";
import { ContractId } from "@daml/types";

// Daml Logic
import { KYC } from "@daml.js/CantonSuite-0.1.0/lib/KYC";
import { DraftRWAInstrument } from "@daml.js/CantonSuite-0.1.0/lib/Finance/Instruments";
import { ComplianceReviewRequest } from "@daml.js/CantonSuite-0.1.0/lib/Trade";
import { SanctionsRegistry, SanctionsClearance } from "@daml.js/CantonSuite-0.1.0/lib/Compliance/SanctionsRegistry";
import { ComplianceApprovalVoucher } from "@daml.js/CantonSuite-0.1.0/lib/Compliance/Vouchers";

// UI Helpers
import { useToast } from "../context/ToastContext";
import { TableSkeleton } from "../components/LoadingSpinner";
import Modal from "../components/Modal";
import CantonIAM from "../services/CantonIAM";

export default function ComplianceDashboard() {
  const ledger = useLedger();
  const party = useParty();
  const toast = useToast();
  const iam = CantonIAM.getInstance();

  const [activeTab, setActiveTab] = useState<"KYC" | "ASSETS" | "TRADES" | "SANCTIONS">("KYC");
  const [loadingId, setLoadingId] = useState<string | null>(null);

  // --- DATA STREAMS ---
  const { contracts: kycReqs, loading: kycLoading } = useStreamQueries(KYC);
  const { contracts: drafts, loading: assetLoading } = useStreamQueries(DraftRWAInstrument);
  const { contracts: tradeReviews, loading: tradeLoading } = useStreamQueries(ComplianceReviewRequest);
  const { contracts: registries } = useStreamQueries(SanctionsRegistry);
  const { contracts: clearances } = useStreamQueries(SanctionsClearance);
  const { contracts: vouchers } = useStreamQueries(ComplianceApprovalVoucher);

  // --- HANDLERS: KYC ---
  const handleApproveKYC = async (cid: string) => {
    setLoadingId(cid);
    try {
      // SECTION A.2: Approving KYC creates a ComplianceApprovalVoucher automatically in the backend
      await ledger.exercise(KYC.Approve, cid as ContractId<KYC>, {
        approvalReason: "Standard Institutional Due Diligence Passed",
        maxTradeAmount: "1000000.0", // $1M limit
        voucherDuration: "365"
      });
      toast.showToast("Investor Verified. Trading Voucher issued.", "success");
    } catch (e: any) { toast.showToast(e.message, "error"); }
    setLoadingId(null);
  };

  // --- HANDLERS: ASSET ISSUANCE ---
  const handleFinalizeAsset = async (cid: string) => {
    setLoadingId(cid);
    try {
      // Logic: Compliance moves the draft to a live RWAInstrument
      await ledger.exercise(DraftRWAInstrument.FinalizeIssuance, cid as ContractId<DraftRWAInstrument>, {
        additionalObservers: [],
        description: "Regulated RWA Instrument",
        validAsOf: new Date().toISOString()
      });
      toast.showToast("Asset Vetted and Finalized for Secondary Trading.", "success");
    } catch (e: any) { toast.showToast(e.message, "error"); }
    setLoadingId(null);
  };

  // --- HANDLERS: TRADE REVIEW ---
  const handleApproveTrade = async (review: any) => {
    setLoadingId(review.contractId);
    try {
      // We need to find active vouchers for both parties to satisfy the IssueApprovalVoucher choice
      const buyerVoucher = vouchers.find(v => v.payload.approvedParty === review.payload.buyer);
      const sellerVoucher = vouchers.find(v => v.payload.approvedParty === review.payload.seller);

      if (!buyerVoucher || !sellerVoucher) {
        toast.showToast("Missing KYC vouchers for trade participants.", "error");
        setLoadingId(null);
        return;
      }

      await ledger.exercise(ComplianceReviewRequest.IssueApprovalVoucher, review.contractId, {
        buyerVoucherCid: buyerVoucher.contractId,
        sellerVoucherCid: sellerVoucher.contractId,
        complianceNotes: "Trade volume consistent with investor profile."
      });
      toast.showToast("Trade Approved. Ready for Settlement.", "success");
    } catch (e: any) { toast.showToast(e.message, "error"); }
    setLoadingId(null);
  };

  // --- HANDLERS: SANCTIONS (Hashed AML) ---
  const [targetParty, setTargetParty] = useState("");
  
  // Utility to hash the party ID locally before sending to ledger (Privacy protection)
  const hashParty = async (partyName: string) => {
    const msgBuffer = new TextEncoder().encode(partyName);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const handleAddSanction = async () => {
    if (!registries[0]) return;
    const hashedId = await hashParty(targetParty);
    try {
      await ledger.exercise(SanctionsRegistry.AddSanctionedEntity, registries[0].contractId, {
        partyHash: hashedId,
        reason: "Manual AML Override"
      });
      toast.showToast("Party added to Hashed Blacklist.", "warning");
      setTargetParty("");
    } catch (e: any) { toast.showToast(e.message, "error"); }
  };

  const handleIssueSanctionsClearance = async (review: any) => {
    if (!registries[0]) return;
    try {
      await ledger.exercise(SanctionsRegistry.IssueClearance, registries[0].contractId, {
        partyToCheck: review.payload.buyer,
        tradeId: review.payload.tradeId,
        settlementWindow: "3600"
      });
      toast.showToast("Sanctions Clearance Certificate Issued.", "success");
    } catch (e: any) { toast.showToast(e.message, "error"); }
  };

  const tabStyle = (id: string) => ({
    padding: '1rem',
    background: activeTab === id ? 'var(--danger)' : 'transparent',
    color: activeTab === id ? 'white' : 'var(--text-muted)',
    border: 'none',
    borderBottom: activeTab === id ? '3px solid white' : 'none',
    cursor: 'pointer',
    fontWeight: 'bold' as const
  });

  return (
    <div className="container">
      <div className="flex-between" style={{ marginBottom: "2rem" }}>
        <h1 style={{ color: 'var(--danger)' }}>Compliance Dashboard</h1>
        <div style={{ display: 'flex', background: 'var(--bg-card)', borderRadius: '8px' }}>
          <button style={tabStyle("KYC")} onClick={() => setActiveTab("KYC")}>KYC ({kycReqs.filter(k=>k.payload.status.tag==='KPending').length})</button>
          <button style={tabStyle("ASSETS")} onClick={() => setActiveTab("ASSETS")}>Assets ({drafts.length})</button>
          <button style={tabStyle("TRADES")} onClick={() => setActiveTab("TRADES")}>Trades ({tradeReviews.length})</button>
          <button style={tabStyle("SANCTIONS")} onClick={() => setActiveTab("SANCTIONS")}>AML/Sanctions</button>
        </div>
      </div>

      {/* TAB: KYC APPLICATIONS */}
      {activeTab === "KYC" && (
        <div className="card">
          <h3>Pending Identity Verifications</h3>
          <table>
            <thead><tr><th>Applicant</th><th>Role</th><th>Action</th></tr></thead>
            <tbody>
              {kycReqs.filter(k => k.payload.status.tag === "KPending").map(k => (
                <tr key={k.contractId}>
                  <td style={{ fontFamily: 'monospace' }}>{k.payload.buyer}</td>
                  <td><span className="badge badge-blue">Investor</span></td>
                  <td>
                    <button className="btn-success" disabled={loadingId === k.contractId} onClick={() => handleApproveKYC(k.contractId)}>
                      {loadingId === k.contractId ? "..." : "Approve & Limit $1M"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB: ASSET APPROVALS */}
      {activeTab === "ASSETS" && (
        <div className="card">
          <h3>RWA Issuance Vetting</h3>
          <table>
            <thead><tr><th>Ticker</th><th>Asset Name</th><th>Issuer</th><th>Price</th><th>Action</th></tr></thead>
            <tbody>
              {drafts.map(d => (
                <tr key={d.contractId}>
                  <td><span className="badge badge-blue">{d.payload.instrumentId}</span></td>
                  <td>{d.payload.name}</td>
                  <td>{d.payload.draftIssuer.split('::')[0]}</td>
                  <td>${d.payload.pricePerUnit}</td>
                  <td>
                    <button className="btn-primary" disabled={loadingId === d.contractId} onClick={() => handleFinalizeAsset(d.contractId)}>
                      Finalize Listing
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB: TRADE COMPLIANCE */}
      {activeTab === "TRADES" && (
        <div className="card">
          <h3>Secondary Market Surveillance</h3>
          <table>
            <thead><tr><th>Buyer</th><th>Seller</th><th>Value</th><th>Sanctions</th><th>Action</th></tr></thead>
            <tbody>
              {tradeReviews.map(r => (
                <tr key={r.contractId}>
                  <td style={{ fontSize: '0.7rem' }}>{r.payload.buyer.substring(0,10)}...</td>
                  <td style={{ fontSize: '0.7rem' }}>{r.payload.seller.substring(0,10)}...</td>
                  <td style={{ fontWeight: 'bold' }}>${Number(r.payload.totalValue).toLocaleString()}</td>
                  <td>
                    <button className="btn-outline" style={{ fontSize: '0.7rem' }} onClick={() => handleIssueSanctionsClearance(r)}>
                      Run AML Check
                    </button>
                  </td>
                  <td>
                    <button className="btn-success" onClick={() => handleApproveTrade(r)}>Authorize Trade</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB: SANCTIONS REGISTRY */}
      {activeTab === "SANCTIONS" && (
        <div className="grid-cols-2">
          <div className="card">
            <h3>Hashed Sanctions Blacklist</h3>
            <div className="flex-gap" style={{ marginBottom: '1.5rem' }}>
              <input 
                className="input-field" 
                placeholder="Party Name to Blacklist" 
                value={targetParty}
                onChange={e => setTargetParty(e.target.value)}
              />
              <button className="btn-danger" onClick={handleAddSanction}>Blacklist Hash</button>
            </div>
            
            <h4 className="text-muted">Currently Blacklisted Hashes (Anonymized)</h4>
            <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {registries[0]?.payload.sanctionedHashes.map(h => (
                <div key={h} style={{ fontSize: '0.7rem', fontFamily: 'monospace', padding: '0.5rem', borderBottom: '1px solid var(--border)' }}>
                  {h}
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h3>Active Sanctions Clearances</h3>
            <p className="text-muted">One-time certificates issued for specific trades.</p>
            {clearances.map(c => (
              <div key={c.contractId} className="flex-between" style={{ padding: '0.5rem', background: 'var(--bg-dark)', borderRadius: '4px', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '0.8rem' }}>Trade: {c.payload.tradeId}</span>
                <span className="badge badge-green">Cleared</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}