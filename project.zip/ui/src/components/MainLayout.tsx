// ui/src/components/MainLayout.tsx
import React from "react";
import { useParty, useStreamQueries } from "@daml/react";
import { User } from "@daml.js/CantonSuite-0.1.0/lib/Users";
import { LoadingSpinner } from "./LoadingSpinner";
import SyncStatus from "./SyncStatus";
// Modern Dashboards (we will populate these next)
import BuyerDashboard from "../pages/BuyerDashboard";
import IssuerDashboard from "../pages/IssuerDashboard";
import ComplianceDashboard from "../pages/ComplianceDashboard";
import RegulatorDashboard from "../pages/RegulatorDashboard";

const MainLayout: React.FC = () => {
  const party = useParty();
  const { contracts: userContracts, loading } = useStreamQueries(User);

  if (loading) return <LoadingSpinner text="Authorizing Protocol Access..." />;

  const userProfile = userContracts.find(u => u.payload.partyId === party);

  // If StartupScript hasn't run or party isn't recognized
  if (!userProfile) {
    return (
      <div className="login-container">
        <div className="card" style={{ maxWidth: '500px', textAlign: 'center', border: '1px solid var(--danger)' }}>
          <h2 style={{ color: 'var(--danger)' }}>Identity Mismatch</h2>
          <p>The party <code>{party}</code> is allocated on the node, but no <b>User Profile</b> contract was found on the ledger.</p>
          <p className="text-muted" style={{ fontSize: '0.8rem' }}>Please ensure the <code>StartupScript.daml</code> has been executed to initialize institutional roles.</p>
          <button className="btn-primary" onClick={() => window.location.reload()}>Retry Ledger Sync</button>
        </div>
      </div>
    );
  }

  const { name, role } = userProfile.payload;

  const renderDashboard = () => {
    switch (role) {
      case "Buyer":      return <BuyerDashboard />;
      case "Issuer":     return <IssuerDashboard />;
      case "Compliance": return <ComplianceDashboard />;
      case "Regulator":  return <RegulatorDashboard />;
      default:           return <div className="card">Unknown Role: {role}</div>;
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* INSTITUTIONAL HEADER */}
      <header style={{ 
        padding: '0.75rem 2rem', 
        background: 'var(--bg-card)', 
        borderBottom: '1px solid var(--border)',
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        position: 'sticky', top: 0, zIndex: 1000,
        boxShadow: '0 4px 20px rgba(0,0,0,0.4)'
      }}>
        <div className="flex-gap">
          <span style={{ fontWeight: 900, color: 'var(--primary)', fontSize: '1.1rem', letterSpacing: '1px' }}>
            CANTON SUITE+
          </span>
          <span className={`badge ${role === 'Buyer' ? 'badge-green' : role === 'Issuer' ? 'badge-blue' : 'badge-yellow'}`}>
            {role.toUpperCase()}
          </span>
        </div>

        {/* Global Network Health (Mining Rounds) */}
        <SyncStatus />
        
        <div className="flex-gap">
          <div style={{ textAlign: 'right', lineHeight: '1.2' }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 'bold' }}>{name}</div>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>
                {party}
            </div>
          </div>
          <button className="btn-outline" style={{ padding: '4px 12px' }} onClick={() => { localStorage.clear(); window.location.reload(); }}>
            Logout
          </button>
        </div>
      </header>

      {/* DASHBOARD AREA */}
      <main style={{ flex: 1, padding: '2rem' }}>
        {renderDashboard()}
      </main>
      
      <footer style={{ 
        padding: '1rem', textAlign: 'center', 
        borderTop: '1px solid var(--border)', 
        fontSize: '0.7rem', color: '#4b5563',
        background: '#0b0e11'
      }}>
        Boutique RWA Infrastructure | Hashed Audit Enabled | Synchronizer: <b>sandbox</b>
      </footer>
    </div>
  );
};

export default MainLayout;