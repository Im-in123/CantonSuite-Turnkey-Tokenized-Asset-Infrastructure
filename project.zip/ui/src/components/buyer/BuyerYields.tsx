import React from "react";
import { useLedger, useParty, useStreamQueries } from "@daml/react";
import { DividendAnnouncement, DividendClaim } from "@daml.js/CantonSuite-0.1.0/lib/Distribution/ClaimBased";
import { useToast } from "../../context/ToastContext";

export default function BuyerYields() {
  const party = useParty();
  const ledger = useLedger();
  const toast = useToast();

  // 1. Find announcements where I am an observer
  const { contracts: announcements } = useStreamQueries(DividendAnnouncement);
  // 2. Find claims I've already made
  const { contracts: myClaims } = useStreamQueries(DividendClaim, () => [{ holder: party }]);

  const handleClaim = async (ann: any) => {
    try {
      // Logic: SECTION D.2 - Investor provides proof (can be CID or hash) to claim
      await ledger.exercise(DividendAnnouncement.ClaimDividend, ann.contractId, {
        holder: party,
        holdingSnapshot: "10.0", // In production, this matches the snapshot balance
        proofOfOwnership: "Canton-Verified-Holding-Hash"
      });
      toast.showToast("Yield claimed. Voucher added to portfolio.", "success");
    } catch (e: any) { toast.showToast(e.message, "error"); }
  };

  return (
    <div className="card">
      <h3>Available Yield Distributions</h3>
      {announcements.map(a => {
        const alreadyClaimed = myClaims.some(c => c.payload.announcementId === a.payload.announcementId);
        
        return (
          <div key={a.contractId} className="flex-between" style={{ padding: '1rem', background: 'var(--bg-dark)', marginBottom: '0.5rem', borderRadius: '8px' }}>
            <div>
              <strong>{a.payload.dividendLabel}</strong>
              <div className="text-muted" style={{fontSize: '0.7rem'}}>{a.payload.assetId} | ${a.payload.perUnitAmount} per unit</div>
            </div>
            {alreadyClaimed ? (
              <span className="badge badge-green">Claimed</span>
            ) : (
              <button className="btn-success" onClick={() => handleClaim(a)}>Claim Yield</button>
            )}
          </div>
        );
      })}
    </div>
  );
}