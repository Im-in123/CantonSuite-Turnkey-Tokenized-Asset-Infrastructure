// ui/src/services/CantonIAM.ts

class CantonIAM {
  private static instance: CantonIAM;
  private readonly ledgerId: string = 'sandbox'; 

  private constructor() {}

  static getInstance(): CantonIAM {
    if (!CantonIAM.instance) CantonIAM.instance = new CantonIAM();
    return CantonIAM.instance;
  }

  /**
   * Generates a JWT. 
   * @param partyId The user's unique identity (actAs).
   * @param readAsParties List of identities the user can "see" through (PublicMarket, AmuletApp, etc).
   */
  public createUserToken(partyId: string, readAsParties: string[] = []): string {
    // Ensure the user can always read their own data, plus public data
    const uniqueReadAs = Array.from(new Set([partyId, ...readAsParties]));

    const payload = {
      sub: partyId,
      'https://daml.com/ledger-api': {
        ledgerId: this.ledgerId,
        applicationId: 'CantonSuite_App',
        actAs: [partyId],
        readAs: uniqueReadAs 
      },
      exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
    };

    const header = { alg: 'HS256', typ: 'JWT' };
    const encode = (obj: object) => btoa(JSON.stringify(obj)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    return `${encode(header)}.${encode(payload)}.dummy_signature`;
  }

  async discoverParties(): Promise<Record<string, string>> {
    const token = this.createUserToken('admin');
    const response = await fetch('/v1/parties', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (!response.ok) throw new Error("Canton Node unreachable");
    
    const data = await response.json();
    const mapping: Record<string, string> = {};
    
    const targetParties = [
      'PlatformIssuer', 'Alice', 'Bob', 'Charlie', 'ComplianceOfficer', 
      'Regulator', 'PoolOperator', 'Bank', 'HedgeFund', 'Borrower', 'AmuletApp',
      'PublicMarket' // ✅ NEW: Discovers the shared marketplace identity
    ];
    
    (data.result || []).forEach((p: any) => {
      targetParties.forEach(name => {
        if (p.identifier.startsWith(name) || p.displayName === name) {
          mapping[name] = p.identifier;
        }
      });
    });

    localStorage.setItem('canton_party_map', JSON.stringify(mapping));
    return mapping;
  }

  getPartyByRole(roleName: string): string {
    const map = JSON.parse(localStorage.getItem('canton_party_map') || '{}');
    return map[roleName] || '';
  }

  setSession(token: string, partyId: string): void {
    localStorage.setItem('canton_token', token);
    localStorage.setItem('canton_party', partyId);
  }
}

export default CantonIAM;